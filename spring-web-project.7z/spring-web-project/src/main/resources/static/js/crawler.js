
function webCrowler(){
	
	
	 var search = {}
	 search["rootUrl"] = $("#url").val();
	 alert(JSON.stringify(search))
	$.ajax({
		url : getContextPath() + "/crowler",
		type : 'POST',
		data :JSON.stringify(search),
		contentType : 'application/json',
		success : function(data) {
			toggleLoader(false)
			try {
				//alert("success");
				alert(JSON.stringify(data));
			} catch (err) {
			}
		},
		error : function() {
			toggleLoader(false)
		}
	});
	
};


function getContextPath() {
	return window.location.pathname.substring(0, window.location.pathname.indexOf("/", 2));
}

function toggleLoader(action){
	//$('.loaderWrapper').remove();
	if(action){
		//var time=getTimeOut()
		//$("body").append( '<div class="loaderWrapper"> <div class="load-content"><span class="result">Populating Results</span><div class="loader"></div><span class="time">Resourse not found</span></div></div>'  )
	}
}