package com.dbs.bean;

public class UrlBean {
	
	private String rootUrl;

	public String getRootUrl() {
		return rootUrl;
	}

	public void setRootUrl(String rootUrl) {
		this.rootUrl = rootUrl;
	}

	
	
}
